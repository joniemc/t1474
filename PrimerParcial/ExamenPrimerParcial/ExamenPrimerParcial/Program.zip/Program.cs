﻿using System;

namespace ExamenPrimerParcial {
    public class Program {
        public static void Main(string[] args)
        {
            int opcion;
            do {
                MenuPrincipal();
                opcion = Convert.ToInt16(Console.ReadLine());
                switch (opcion) {
                    case 1:
                        Ejercicio1();
                        break;
                    case 2:
                        //Llamado a la función ejercicio 2
                        break;
                    case 3:
                        //Llamado a la función ejercicio 3
                        break;
                    case 4:
                        Console.WriteLine("Gracias por realizar su examen..");
                        break;
                    default:
                        break;
                }
            } while (opcion!=4);
        }
        public static void MenuPrincipal() {
            Console.WriteLine("================MENU================");
            Console.WriteLine("1. Numeros mayores o menores que 7");
            Console.WriteLine("2. Calcular promedio de ventas por dependiente");
            Console.WriteLine("3. Identificar vocales");
            Console.WriteLine("4. Salir");
        }
        public static void Ejercicio1() {
            int numeroEntero;
            int contadorEsPar=0;
            do {
                Console.Write("Ingrese un numero entero: ");
                numeroEntero = Convert.ToInt32(Console.ReadLine());

                if (numeroEntero%2 == 0) {
                    contadorEsPar++;
                }
                
                Console.WriteLine("El numero ingresado es: "+numeroEntero);
            } while (numeroEntero!=-1);
            Console.WriteLine("la cantidad de numeros pares ingresados es: "+contadorEsPar);
        }
    }
}
﻿using System;

namespace ExamenPrimerParcial {
    public class Program {
        public static void Main(string[] args)
        {

        }
    }
}